# Chapter 2 Exercise 1
library(shiny)
runExample("01_hello")
runExample()
runExample("04_mpg")
