# Chapter 2 Exercise 2
library(shiny)
# Define the user interface component
ui <- fluidPage()
# Define the server component
server <- function(input, output) {}
# Combine the two components
shinyApp(ui = ui, server = server)
